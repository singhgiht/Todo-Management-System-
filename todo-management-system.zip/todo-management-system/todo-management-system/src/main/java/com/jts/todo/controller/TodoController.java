package com.jts.todo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jts.todo.model.TodoItem;
import com.jts.todo.repo.TodoRepository;

@RestController
@RequestMapping(value = "/todo")
public class TodoController {

	@Autowired
	private TodoRepository todoRepository;
	
	@GetMapping
	public List<TodoItem> findAll(){
		return todoRepository.findAll();
	}
	
	@PostMapping
	public TodoItem save(@RequestBody TodoItem todoItem) {
		return todoRepository.save(todoItem);
	}
	
}
