package com.jts.todo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jts.todo.model.TodoItem;

public interface TodoRepository extends JpaRepository<TodoItem, Long>{

	
}
